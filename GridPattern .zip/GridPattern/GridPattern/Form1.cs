﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GridPattern
{
    public partial class Form1 : Form
    {
        int gridViewBackColor = 0;

        public Form1()
        {
            InitializeComponent();

            typeof(Control).InvokeMember("DoubleBuffered"
                , System.Reflection.BindingFlags.SetProperty | System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic
                , null, dgvForm, new object[] { true });

            this.Controls.Add(dgvForm);
            dgvForm.DefaultCellStyle.SelectionBackColor = Color.FromArgb(gridViewBackColor, gridViewBackColor, gridViewBackColor);
        }

        private void btnSetForm_Click(object sender, EventArgs e)
        {
            dgvForm.Rows.Clear();
            dgvForm.Columns.Clear();

            // DataGridView의 컬럼 갯수를 5개(Default)로 설정
            dgvForm.ColumnCount = Convert.ToInt32(textBox3.Text);

            // DataGridView에 빈 스트링 배열을 한 행 단위로 삽입, 이 과정이 생략되면 그리드뷰에 선이 그려지지 않음
            string[] row = { "" };
            for (int n = 0; n < Convert.ToInt32(textBox2.Text); n++)
                dgvForm.Rows.Add(row);

            dgvForm.DefaultCellStyle.Font = new Font("Tahoma", 60);
//             dgvForm.DefaultCellStyle.SelectionForeColor = Color.White;
//             dgvForm.DefaultCellStyle.SelectionBackColor = Color.White;

            // 그리드 뷰의 셀 폭과 전체 크기를 지정
            for (int i = 0; i < dgvForm.Columns.Count; i++)
                dgvForm.Columns[i].Width = 15;

            dgvForm.Width = (15 * Convert.ToInt32(textBox3.Text)) + 20;
            dgvForm.Height = (15 * Convert.ToInt32(textBox2.Text)) + 20;

            // 989, 885 -- 12, 80
            if (dgvForm.Width > 960)
                dgvForm.Width = 960;
            if (dgvForm.Height > 810)
                dgvForm.Height = 810;

            dgvForm.ClearSelection();
        }

        private void dgvForm_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            dgvForm.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.FromArgb(gridViewBackColor, gridViewBackColor, gridViewBackColor);
        }

        private void dgvForm_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            dgvForm.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.FromArgb(100, 100, 100);
        }

        private void dgvForm_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (dgvForm.SelectedCells.Count > 1) // 선택된 셀이 존재한다면,
            {
                foreach (DataGridViewCell cell in dgvForm.SelectedCells) // 선택된 셀들의 색상을 변경
                {
                    cell.Style.BackColor = Color.FromArgb(gridViewBackColor, gridViewBackColor, gridViewBackColor);
                }
            }

            // 드래그 영역 해제, 해제하지 않으면, 선택된 영역이 계속해서 색상 변경의 영향을 받게됨
            dgvForm.ClearSelection();
        }
    }
}
